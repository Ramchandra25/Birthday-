const giftBox = document.getElementById('giftBox');
const message = document.getElementById('message');
const photoGallery = document.getElementById('photoGallery');
const photos = photoGallery.querySelectorAll('.gallery-photo');

// Add sounds
const boxOpenSound = new Audio('box-open.mp3');
const romanticMusic = new Audio('romantic.mp3');
romanticMusic.loop = true;
romanticMusic.volume = 0.5;

function revealPhotosSequentially() {
  photos.forEach((photo, index) => {
    setTimeout(() => {
      photo.classList.add('show');

      if (index === photos.length - 1) {
        setTimeout(() => {
          animateFlashZoomOneByOne();
        }, 2000); // Slight delay before starting zoom-flash
      }
    }, index * 2500);
  });
}


function animateFlashZoomOneByOne() {
  photos.forEach((photo, index) => {
    setTimeout(() => {
      photo.classList.add('flash-zoom');

      // Remove class after animation ends to reset
      setTimeout(() => {
        photo.classList.remove('flash-zoom');
      }, 3000); // Duration of the animation
    }, index * 3200); // Delay between each photo
  });
}







function createBalloons(count = 10) {
  const container = document.querySelector('.container');
  const balloonWrapper = document.createElement('div');
  balloonWrapper.className = 'balloons';

  for (let i = 0; i < count; i++) {
    const balloon = document.createElement('div');
    balloon.className = 'balloon';
    balloon.style.left = Math.random() * 100 + 'vw';
    balloon.style.backgroundColor = `hsl(${Math.random() * 360}, 70%, 60%)`;
    balloon.style.animationDelay = Math.random() * 2 + 's';
    balloonWrapper.appendChild(balloon);
  }

  container.appendChild(balloonWrapper);

  // Remove after animation
  setTimeout(() => {
    balloonWrapper.remove();
  }, 700000);
}

function openGift() {
  giftBox.style.pointerEvents = 'none';
  giftBox.classList.add('open');

  // Play box opening sound
  boxOpenSound.play();

  setTimeout(() => {
    giftBox.style.display = 'none';
    message.classList.remove('hidden');
    photoGallery.classList.remove('hidden');

    // Launch balloons
    createBalloons(15);

    // Reveal photos
    revealPhotosSequentially();

    // Play romantic song
    romanticMusic.play();
  }, 700);
}

// Click and keyboard
giftBox.addEventListener('click', openGift);
giftBox.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' || e.key === ' ') {
    e.preventDefault();
    openGift();
  }
});
